# Changelog

## Version 1.0

Initial public release.

Included software:

* Unified Launcher
* Counting by Length
* Counting by Hamming Weight
* Collatz Calculator
* PV Graph from String
* PV Graph from Number

Included:

* Python implementation
* PHP implementation
* User manuals
* Sample output files

