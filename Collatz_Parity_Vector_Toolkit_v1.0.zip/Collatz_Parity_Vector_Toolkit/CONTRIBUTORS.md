# Contributors

## Author

Kazunobu Hikawa

Professor Emeritus

Kanazawa Gakuin University

---

This software was developed by the author as part of the research on

Parity Vector Geometry for the Collatz Conjecture.
